<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */



// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define('DB_NAME', 'howardfo_lng_r_jxcz');



/** MySQL database username */

define('DB_USER', 'howardfo_8JY3PVW');



/** MySQL database password */

define('DB_PASSWORD', '^2>W`rBg(wjL]r_>Nywn#M\'+f3+HD2<w');



/** MySQL hostname */

define('DB_HOST', 'localhost');



/** Database Charset to use in creating database tables. */

define('DB_CHARSET', 'utf8mb4');



/** The Database Collate type. Don't change this if in doubt. */

define('DB_COLLATE', '');



/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define('AUTH_KEY',         'D8n%Kcb47?1FPTTn]m4I{f[+[!)/OWp|:rJc9gc(Tx3D}F+>}2t?e5SPxL_o7u^w');

define('SECURE_AUTH_KEY',  '4X.b<%07P#bK&s1-@,s!5P0zKtt8q~E]vz@<m,Xv!RdrO1sz$}GB]m `-843>s%1');

define('LOGGED_IN_KEY',    '=;;X>stomOLotnjhZv{-QJ:cq 5b.!8z}*aEwj|DZw4t%.Y=<[36z>;T76ZOW_eQ');

define('NONCE_KEY',        '8U$nGa O!u]+vwJ?u:0c<^B}Lq_W*!XM.MvwUKS8Pu_6,qUcmzDJ;r&eoB`dF?Qv');

define('AUTH_SALT',        'R;6rBg/t)wj%Tv[a|aCO86^3uxHYZ++Ka~7>z}ld=6LQk>2aHE|*ki7:v=o7QbK7');

define('SECURE_AUTH_SALT', '6c^15GJ~DZ.@{@TKgdt#I3^$yC<vk+-6&9**0@C*|e4CAvO#:^mZ#81qsd,._p~N');

define('LOGGED_IN_SALT',   'd^YK5tF#6`s$`M9r3Fumj+BNZ4s][W8f:PT.lt!Imw85plS-Fje=ahJ@%AR/;m~6');

define('NONCE_SALT',       'QByCD1t.d&@s!$FhhDmwP$<^h<n_,Rajn~&9?X8@G-{3EnE3C`7H2dzPdegO&2:b');



/**#@-*/



/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix  = 'wp_';



/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define('WP_DEBUG', false);



/* That's all, stop editing! Happy blogging. */



/** Absolute path to the WordPress directory. */

if ( !defined('ABSPATH') )

	define('ABSPATH', dirname(__FILE__) . '/');



/** Sets up WordPress vars and included files. */

require_once(ABSPATH . 'wp-settings.php');

